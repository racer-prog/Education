name = 'Roman'
print(f'Name: {name}')
age = 40
print(f'Age: {age}')
age = age+5
print(f'New Age: {age}')
is_student = True
print(f'Is Student: {is_student}')