count_finish_home_task = 12
count_hours = 1.5
name_of_course = 'Python'
one_task_time = count_hours/count_finish_home_task
print(f'Курс {name_of_course}, всего задач: {count_finish_home_task}, среднее время выполнения {one_task_time} часа.')
