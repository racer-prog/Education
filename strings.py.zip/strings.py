example = "Hello World!"
print(example[0])
print(example[-1])
print(example[len(example)//2:])
print(example[::-1])
print(example[1::2])